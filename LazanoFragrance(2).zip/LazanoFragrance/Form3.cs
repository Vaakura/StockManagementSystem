﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LazanoFragrance
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void stockBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.stockBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kombataDataSet);

        }

        private void Form3_Load(object sender, EventArgs e)
        {


            // TODO: This line of code loads data into the 'kombataDataSet.stock' table. You can move, or remove it, as needed.
            this.stockTableAdapter.Fill(this.kombataDataSet.stock);
            lblTime.Text = DateTime.Now.ToLongTimeString();
            lblDate.Text = DateTime.Now.ToLongDateString();


            cmbSearch1.Items.Add("productCode");
            // cmbSearch1.Items.Add("invoiceNo");


        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Hide();
            new Form2().Show();


        }

        private void button4_Click(object sender, EventArgs e)
        {
            Hide();
            new Form4().Show();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Confirm if you want to exit", "Stock Control", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.stockBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kombataDataSet);


            richTextBox1.AppendText(Environment.NewLine);
            richTextBox1.AppendText(".........................................................................................." + Environment.NewLine);
            richTextBox1.AppendText("                         LAZANAO FRAGRANCE                                 " + Environment.NewLine);
            richTextBox1.AppendText("..........................................................................................." + Environment.NewLine);
            richTextBox1.AppendText("..........................................................................................." + Environment.NewLine);
            richTextBox1.AppendText("  P.O BOX 875                                  " + Environment.NewLine);
            richTextBox1.AppendText("  OYJTOMUISE                                  " + Environment.NewLine);
            richTextBox1.AppendText("  WINDHOEK                                  " + Environment.NewLine);
            richTextBox1.AppendText("..........................................................................................." + Environment.NewLine);
            richTextBox1.AppendText("PRODUCT CODE: " + "\t" + productCode.Text + Environment.NewLine);
            richTextBox1.AppendText("Description: " + "\t" + descriptionTextBox.Text + Environment.NewLine);
            richTextBox1.AppendText("Category: " + "\t" + categoryTextBox.Text + Environment.NewLine);
            richTextBox1.AppendText("Sales price: " + "\t" + salePriceTextBox.Text + Environment.NewLine);
            richTextBox1.AppendText("Item Type: " + "\t" + itemTypeTextBox.Text + Environment.NewLine);
            richTextBox1.AppendText("Weight: " + "\t" + weightTextBox.Text + Environment.NewLine);
            richTextBox1.AppendText("Cost Price: " + "\t" + costPriceTextBox.Text + Environment.NewLine);
            richTextBox1.AppendText(Environment.NewLine);
            richTextBox1.AppendText("............................................................................................");
            richTextBox1.AppendText(Environment.NewLine);
            richTextBox1.AppendText(lblDate.Text + "\t" + Environment.NewLine);
            richTextBox1.AppendText(lblTime.Text + "\t" + Environment.NewLine);

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfile = new OpenFileDialog();

            openfile.Filter = "Text Files(*.txt)|*.txt|All files(*.*)|*.*";

            if (openfile.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                richTextBox1.LoadFile(openfile.FileName, RichTextBoxStreamType.PlainText);

        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFile = new SaveFileDialog();

            saveFile.FileName = "Notepad Text";
            saveFile.Filter = "Text Files(*.txt)|*.txt|All files(*.*)|*.*";

            if (saveFile.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {

                using (System.IO.StreamWriter sw = new System.IO.StreamWriter(saveFile.FileName))
                    sw.WriteLine(richTextBox1.Text);
            }
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(richTextBox1.Text, new Font("Arial", 20, FontStyle.Regular), Brushes.Black, 120, 120);
        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            String LazanoFragrance;
            LazanoFragrance = cmbSearch1.Text;
            switch (LazanoFragrance)
            {
                case "productCode":
                    this.stockBindingSource.Filter = "productCode =" + System.Convert.ToString(txtSearch.Text);
                    break;
                /*
            case "":
                this.stockBindingSource.Filter = " =" + (txtSearch.Text);
                break;
            case "i":
                this.stockBindingSource.Filter = " =" + System.Convert.ToString(txtSearch.Text);
                break;
                  */
            }

        }

        private void stockBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.stockBindingSource.MoveNext();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.stockBindingSource.MovePrevious();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();


        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LazanoFragrance
{
    public partial class Form1 : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=kombata;Integrated Security=True");
       

        SqlCommand cmd;
        SqlDataReader dr;

        
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
                conn.Open();
                string sql = "select*from Login where Type='ceo' or Type='teller' and Username like '%" + txtUsername.Text + "%' and Password like '%" + txtPassword.Text + "%'";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader dr = cmd.ExecuteReader();
                dr.Read();
                try
                {
                    if (dr.HasRows == true)
                    {
                        txtUsername.Text = dr[1].ToString();
                        txtPassword.Text = dr[2].ToString();
                        MessageBox.Show("Successfully Login", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        Form3 f3 = new Form3();
                        f3.Show();
                        this.Hide();
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Invalid Username or Password", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                dr.Close();
                conn.Close();
            }
         

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Confirm if you want to exit", "Stock Control", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 f3 = new Form3();
            f3.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {

            DialogResult iExit;
            iExit = MessageBox.Show("Confirm if you want to exit", "Stock Control", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (iExit == DialogResult.Yes)
            {
                Application.Exit();


            }
        }
    }
}
﻿namespace LazanoFragrance
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label productCodeLabel;
            System.Windows.Forms.Label descriptionLabel;
            System.Windows.Forms.Label departmentLabel;
            System.Windows.Forms.Label categoryLabel;
            System.Windows.Forms.Label locationLabel;
            System.Windows.Forms.Label comCodeLabel;
            System.Windows.Forms.Label nominalCodeLabel;
            System.Windows.Forms.Label supplierAccountLabel;
            System.Windows.Forms.Label salePriceLabel;
            System.Windows.Forms.Label itemTypeLabel;
            System.Windows.Forms.Label weightLabel;
            System.Windows.Forms.Label taxCodeLabel;
            System.Windows.Forms.Label partNumberLabel;
            System.Windows.Forms.Label unitOfSaleLabel;
            System.Windows.Forms.Label stockTakeLabel;
            System.Windows.Forms.Label inStockLabel;
            System.Windows.Forms.Label allocatedLabel;
            System.Windows.Forms.Label freeStockLabel;
            System.Windows.Forms.Label onOrderLabel;
            System.Windows.Forms.Label lastOrderDateLabel;
            System.Windows.Forms.Label reOrderDateLabel;
            System.Windows.Forms.Label reOrderLevelLabel;
            System.Windows.Forms.Label reOrderQtyLabel;
            System.Windows.Forms.Label costPriceLabel;
            System.Windows.Forms.Label stockTakeQuantityLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblTime = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.inStockTextBox = new System.Windows.Forms.TextBox();
            this.stockBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kombataDataSet = new LazanoFragrance.kombataDataSet();
            this.weightTextBox = new System.Windows.Forms.TextBox();
            this.allocatedTextBox = new System.Windows.Forms.TextBox();
            this.comCodeTextBox = new System.Windows.Forms.TextBox();
            this.freeStockTextBox = new System.Windows.Forms.TextBox();
            this.onOrderTextBox = new System.Windows.Forms.TextBox();
            this.taxCodeTextBox = new System.Windows.Forms.TextBox();
            this.lastOrderDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.departmentTextBox = new System.Windows.Forms.TextBox();
            this.reOrderDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.partNumberTextBox = new System.Windows.Forms.TextBox();
            this.reOrderLevelTextBox = new System.Windows.Forms.TextBox();
            this.nominalCodeTextBox = new System.Windows.Forms.TextBox();
            this.unitOfSaleTextBox = new System.Windows.Forms.TextBox();
            this.reOrderQtyTextBox = new System.Windows.Forms.TextBox();
            this.productCode = new System.Windows.Forms.TextBox();
            this.costPriceTextBox = new System.Windows.Forms.TextBox();
            this.stockTakeTextBox = new System.Windows.Forms.TextBox();
            this.stockTakeQuantityTextBox = new System.Windows.Forms.TextBox();
            this.locationTextBox = new System.Windows.Forms.TextBox();
            this.supplierAccountTextBox = new System.Windows.Forms.TextBox();
            this.salePriceTextBox = new System.Windows.Forms.TextBox();
            this.descriptionTextBox = new System.Windows.Forms.TextBox();
            this.categoryTextBox = new System.Windows.Forms.TextBox();
            this.itemTypeTextBox = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.lblDate = new System.Windows.Forms.ToolStripLabel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.stockTableAdapter = new LazanoFragrance.kombataDataSetTableAdapters.stockTableAdapter();
            this.tableAdapterManager = new LazanoFragrance.kombataDataSetTableAdapters.TableAdapterManager();
            this.stockBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.stockBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox2 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.cmbSearch1 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.txtSearch = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.stockDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            productCodeLabel = new System.Windows.Forms.Label();
            descriptionLabel = new System.Windows.Forms.Label();
            departmentLabel = new System.Windows.Forms.Label();
            categoryLabel = new System.Windows.Forms.Label();
            locationLabel = new System.Windows.Forms.Label();
            comCodeLabel = new System.Windows.Forms.Label();
            nominalCodeLabel = new System.Windows.Forms.Label();
            supplierAccountLabel = new System.Windows.Forms.Label();
            salePriceLabel = new System.Windows.Forms.Label();
            itemTypeLabel = new System.Windows.Forms.Label();
            weightLabel = new System.Windows.Forms.Label();
            taxCodeLabel = new System.Windows.Forms.Label();
            partNumberLabel = new System.Windows.Forms.Label();
            unitOfSaleLabel = new System.Windows.Forms.Label();
            stockTakeLabel = new System.Windows.Forms.Label();
            inStockLabel = new System.Windows.Forms.Label();
            allocatedLabel = new System.Windows.Forms.Label();
            freeStockLabel = new System.Windows.Forms.Label();
            onOrderLabel = new System.Windows.Forms.Label();
            lastOrderDateLabel = new System.Windows.Forms.Label();
            reOrderDateLabel = new System.Windows.Forms.Label();
            reOrderLevelLabel = new System.Windows.Forms.Label();
            reOrderQtyLabel = new System.Windows.Forms.Label();
            costPriceLabel = new System.Windows.Forms.Label();
            stockTakeQuantityLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kombataDataSet)).BeginInit();
            this.panel4.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockBindingNavigator)).BeginInit();
            this.stockBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockDataGridView)).BeginInit();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // productCodeLabel
            // 
            productCodeLabel.AutoSize = true;
            productCodeLabel.Location = new System.Drawing.Point(6, 17);
            productCodeLabel.Name = "productCodeLabel";
            productCodeLabel.Size = new System.Drawing.Size(75, 13);
            productCodeLabel.TabIndex = 5;
            productCodeLabel.Text = "Product Code:";
            // 
            // descriptionLabel
            // 
            descriptionLabel.AutoSize = true;
            descriptionLabel.Location = new System.Drawing.Point(6, 43);
            descriptionLabel.Name = "descriptionLabel";
            descriptionLabel.Size = new System.Drawing.Size(63, 13);
            descriptionLabel.TabIndex = 7;
            descriptionLabel.Text = "Description:";
            // 
            // departmentLabel
            // 
            departmentLabel.AutoSize = true;
            departmentLabel.Location = new System.Drawing.Point(6, 69);
            departmentLabel.Name = "departmentLabel";
            departmentLabel.Size = new System.Drawing.Size(65, 13);
            departmentLabel.TabIndex = 9;
            departmentLabel.Text = "Department:";
            // 
            // categoryLabel
            // 
            categoryLabel.AutoSize = true;
            categoryLabel.Location = new System.Drawing.Point(6, 95);
            categoryLabel.Name = "categoryLabel";
            categoryLabel.Size = new System.Drawing.Size(52, 13);
            categoryLabel.TabIndex = 11;
            categoryLabel.Text = "Category:";
            // 
            // locationLabel
            // 
            locationLabel.AutoSize = true;
            locationLabel.Location = new System.Drawing.Point(6, 121);
            locationLabel.Name = "locationLabel";
            locationLabel.Size = new System.Drawing.Size(47, 13);
            locationLabel.TabIndex = 13;
            locationLabel.Text = "location:";
            // 
            // comCodeLabel
            // 
            comCodeLabel.AutoSize = true;
            comCodeLabel.Location = new System.Drawing.Point(337, 232);
            comCodeLabel.Name = "comCodeLabel";
            comCodeLabel.Size = new System.Drawing.Size(59, 13);
            comCodeLabel.TabIndex = 15;
            comCodeLabel.Text = "Com Code:";
            // 
            // nominalCodeLabel
            // 
            nominalCodeLabel.AutoSize = true;
            nominalCodeLabel.Location = new System.Drawing.Point(6, 151);
            nominalCodeLabel.Name = "nominalCodeLabel";
            nominalCodeLabel.Size = new System.Drawing.Size(76, 13);
            nominalCodeLabel.TabIndex = 17;
            nominalCodeLabel.Text = "Nominal Code:";
            // 
            // supplierAccountLabel
            // 
            supplierAccountLabel.AutoSize = true;
            supplierAccountLabel.Location = new System.Drawing.Point(6, 177);
            supplierAccountLabel.Name = "supplierAccountLabel";
            supplierAccountLabel.Size = new System.Drawing.Size(91, 13);
            supplierAccountLabel.TabIndex = 19;
            supplierAccountLabel.Text = "Supplier Account:";
            // 
            // salePriceLabel
            // 
            salePriceLabel.AutoSize = true;
            salePriceLabel.Location = new System.Drawing.Point(6, 203);
            salePriceLabel.Name = "salePriceLabel";
            salePriceLabel.Size = new System.Drawing.Size(58, 13);
            salePriceLabel.TabIndex = 21;
            salePriceLabel.Text = "Sale Price:";
            // 
            // itemTypeLabel
            // 
            itemTypeLabel.AutoSize = true;
            itemTypeLabel.Location = new System.Drawing.Point(337, 180);
            itemTypeLabel.Name = "itemTypeLabel";
            itemTypeLabel.Size = new System.Drawing.Size(57, 13);
            itemTypeLabel.TabIndex = 23;
            itemTypeLabel.Text = "Item Type:";
            // 
            // weightLabel
            // 
            weightLabel.AutoSize = true;
            weightLabel.Location = new System.Drawing.Point(337, 153);
            weightLabel.Name = "weightLabel";
            weightLabel.Size = new System.Drawing.Size(41, 13);
            weightLabel.TabIndex = 25;
            weightLabel.Text = "weight:";
            // 
            // taxCodeLabel
            // 
            taxCodeLabel.AutoSize = true;
            taxCodeLabel.Location = new System.Drawing.Point(669, 235);
            taxCodeLabel.Name = "taxCodeLabel";
            taxCodeLabel.Size = new System.Drawing.Size(56, 13);
            taxCodeLabel.TabIndex = 27;
            taxCodeLabel.Text = "Tax Code:";
            // 
            // partNumberLabel
            // 
            partNumberLabel.AutoSize = true;
            partNumberLabel.Location = new System.Drawing.Point(337, 205);
            partNumberLabel.Name = "partNumberLabel";
            partNumberLabel.Size = new System.Drawing.Size(69, 13);
            partNumberLabel.TabIndex = 29;
            partNumberLabel.Text = "Part Number:";
            // 
            // unitOfSaleLabel
            // 
            unitOfSaleLabel.AutoSize = true;
            unitOfSaleLabel.Location = new System.Drawing.Point(6, 228);
            unitOfSaleLabel.Name = "unitOfSaleLabel";
            unitOfSaleLabel.Size = new System.Drawing.Size(67, 13);
            unitOfSaleLabel.TabIndex = 31;
            unitOfSaleLabel.Text = "Unit Of Sale:";
            // 
            // stockTakeLabel
            // 
            stockTakeLabel.AutoSize = true;
            stockTakeLabel.Location = new System.Drawing.Point(337, 257);
            stockTakeLabel.Name = "stockTakeLabel";
            stockTakeLabel.Size = new System.Drawing.Size(66, 13);
            stockTakeLabel.TabIndex = 33;
            stockTakeLabel.Text = "Stock Take:";
            // 
            // inStockLabel
            // 
            inStockLabel.AutoSize = true;
            inStockLabel.Location = new System.Drawing.Point(669, 28);
            inStockLabel.Name = "inStockLabel";
            inStockLabel.Size = new System.Drawing.Size(50, 13);
            inStockLabel.TabIndex = 35;
            inStockLabel.Text = "In Stock:";
            // 
            // allocatedLabel
            // 
            allocatedLabel.AutoSize = true;
            allocatedLabel.Location = new System.Drawing.Point(669, 55);
            allocatedLabel.Name = "allocatedLabel";
            allocatedLabel.Size = new System.Drawing.Size(54, 13);
            allocatedLabel.TabIndex = 37;
            allocatedLabel.Text = "Allocated:";
            // 
            // freeStockLabel
            // 
            freeStockLabel.AutoSize = true;
            freeStockLabel.Location = new System.Drawing.Point(669, 81);
            freeStockLabel.Name = "freeStockLabel";
            freeStockLabel.Size = new System.Drawing.Size(62, 13);
            freeStockLabel.TabIndex = 39;
            freeStockLabel.Text = "Free Stock:";
            // 
            // onOrderLabel
            // 
            onOrderLabel.AutoSize = true;
            onOrderLabel.Location = new System.Drawing.Point(669, 107);
            onOrderLabel.Name = "onOrderLabel";
            onOrderLabel.Size = new System.Drawing.Size(53, 13);
            onOrderLabel.TabIndex = 41;
            onOrderLabel.Text = "On Order:";
            // 
            // lastOrderDateLabel
            // 
            lastOrderDateLabel.AutoSize = true;
            lastOrderDateLabel.Location = new System.Drawing.Point(669, 134);
            lastOrderDateLabel.Name = "lastOrderDateLabel";
            lastOrderDateLabel.Size = new System.Drawing.Size(85, 13);
            lastOrderDateLabel.TabIndex = 43;
            lastOrderDateLabel.Text = "Last Order Date:";
            // 
            // reOrderDateLabel
            // 
            reOrderDateLabel.AutoSize = true;
            reOrderDateLabel.Location = new System.Drawing.Point(669, 160);
            reOrderDateLabel.Name = "reOrderDateLabel";
            reOrderDateLabel.Size = new System.Drawing.Size(79, 13);
            reOrderDateLabel.TabIndex = 45;
            reOrderDateLabel.Text = "Re Order Date:";
            // 
            // reOrderLevelLabel
            // 
            reOrderLevelLabel.AutoSize = true;
            reOrderLevelLabel.Location = new System.Drawing.Point(669, 185);
            reOrderLevelLabel.Name = "reOrderLevelLabel";
            reOrderLevelLabel.Size = new System.Drawing.Size(82, 13);
            reOrderLevelLabel.TabIndex = 47;
            reOrderLevelLabel.Text = "Re Order Level:";
            // 
            // reOrderQtyLabel
            // 
            reOrderQtyLabel.AutoSize = true;
            reOrderQtyLabel.Location = new System.Drawing.Point(669, 211);
            reOrderQtyLabel.Name = "reOrderQtyLabel";
            reOrderQtyLabel.Size = new System.Drawing.Size(72, 13);
            reOrderQtyLabel.TabIndex = 49;
            reOrderQtyLabel.Text = "Re Order Qty:";
            // 
            // costPriceLabel
            // 
            costPriceLabel.AutoSize = true;
            costPriceLabel.Location = new System.Drawing.Point(6, 256);
            costPriceLabel.Name = "costPriceLabel";
            costPriceLabel.Size = new System.Drawing.Size(58, 13);
            costPriceLabel.TabIndex = 51;
            costPriceLabel.Text = "Cost Price:";
            // 
            // stockTakeQuantityLabel
            // 
            stockTakeQuantityLabel.AutoSize = true;
            stockTakeQuantityLabel.Location = new System.Drawing.Point(669, 263);
            stockTakeQuantityLabel.Name = "stockTakeQuantityLabel";
            stockTakeQuantityLabel.Size = new System.Drawing.Size(108, 13);
            stockTakeQuantityLabel.TabIndex = 53;
            stockTakeQuantityLabel.Text = "Stock Take Quantity:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Peru;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1338, 61);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(408, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(409, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "LAZANAO STOCK CONTROL";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Peru;
            this.panel2.Controls.Add(this.lblTime);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(12, 93);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1338, 44);
            this.panel2.TabIndex = 1;
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.Location = new System.Drawing.Point(1138, 15);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(60, 24);
            this.lblTime.TabIndex = 1;
            this.lblTime.Text = "label3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(551, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 29);
            this.label2.TabIndex = 0;
            this.label2.Text = "STOCK";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Peru;
            this.panel3.Controls.Add(inStockLabel);
            this.panel3.Controls.Add(weightLabel);
            this.panel3.Controls.Add(this.inStockTextBox);
            this.panel3.Controls.Add(comCodeLabel);
            this.panel3.Controls.Add(allocatedLabel);
            this.panel3.Controls.Add(this.weightTextBox);
            this.panel3.Controls.Add(this.allocatedTextBox);
            this.panel3.Controls.Add(this.comCodeTextBox);
            this.panel3.Controls.Add(freeStockLabel);
            this.panel3.Controls.Add(taxCodeLabel);
            this.panel3.Controls.Add(this.freeStockTextBox);
            this.panel3.Controls.Add(onOrderLabel);
            this.panel3.Controls.Add(productCodeLabel);
            this.panel3.Controls.Add(this.onOrderTextBox);
            this.panel3.Controls.Add(this.taxCodeTextBox);
            this.panel3.Controls.Add(lastOrderDateLabel);
            this.panel3.Controls.Add(nominalCodeLabel);
            this.panel3.Controls.Add(this.lastOrderDateDateTimePicker);
            this.panel3.Controls.Add(partNumberLabel);
            this.panel3.Controls.Add(reOrderDateLabel);
            this.panel3.Controls.Add(this.departmentTextBox);
            this.panel3.Controls.Add(this.reOrderDateDateTimePicker);
            this.panel3.Controls.Add(this.partNumberTextBox);
            this.panel3.Controls.Add(reOrderLevelLabel);
            this.panel3.Controls.Add(unitOfSaleLabel);
            this.panel3.Controls.Add(this.reOrderLevelTextBox);
            this.panel3.Controls.Add(this.nominalCodeTextBox);
            this.panel3.Controls.Add(reOrderQtyLabel);
            this.panel3.Controls.Add(this.unitOfSaleTextBox);
            this.panel3.Controls.Add(this.reOrderQtyTextBox);
            this.panel3.Controls.Add(this.productCode);
            this.panel3.Controls.Add(costPriceLabel);
            this.panel3.Controls.Add(stockTakeLabel);
            this.panel3.Controls.Add(this.costPriceTextBox);
            this.panel3.Controls.Add(supplierAccountLabel);
            this.panel3.Controls.Add(stockTakeQuantityLabel);
            this.panel3.Controls.Add(this.stockTakeTextBox);
            this.panel3.Controls.Add(this.stockTakeQuantityTextBox);
            this.panel3.Controls.Add(this.locationTextBox);
            this.panel3.Controls.Add(this.supplierAccountTextBox);
            this.panel3.Controls.Add(descriptionLabel);
            this.panel3.Controls.Add(salePriceLabel);
            this.panel3.Controls.Add(locationLabel);
            this.panel3.Controls.Add(this.salePriceTextBox);
            this.panel3.Controls.Add(this.descriptionTextBox);
            this.panel3.Controls.Add(itemTypeLabel);
            this.panel3.Controls.Add(this.categoryTextBox);
            this.panel3.Controls.Add(this.itemTypeTextBox);
            this.panel3.Controls.Add(departmentLabel);
            this.panel3.Controls.Add(categoryLabel);
            this.panel3.Location = new System.Drawing.Point(12, 143);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1005, 309);
            this.panel3.TabIndex = 2;
            // 
            // inStockTextBox
            // 
            this.inStockTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "InStock", true));
            this.inStockTextBox.Location = new System.Drawing.Point(783, 25);
            this.inStockTextBox.Name = "inStockTextBox";
            this.inStockTextBox.Size = new System.Drawing.Size(200, 20);
            this.inStockTextBox.TabIndex = 36;
            // 
            // stockBindingSource
            // 
            this.stockBindingSource.DataMember = "stock";
            this.stockBindingSource.DataSource = this.kombataDataSet;
            // 
            // kombataDataSet
            // 
            this.kombataDataSet.DataSetName = "kombataDataSet";
            this.kombataDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // weightTextBox
            // 
            this.weightTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "weight", true));
            this.weightTextBox.Location = new System.Drawing.Point(451, 150);
            this.weightTextBox.Name = "weightTextBox";
            this.weightTextBox.Size = new System.Drawing.Size(200, 20);
            this.weightTextBox.TabIndex = 26;
            // 
            // allocatedTextBox
            // 
            this.allocatedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "Allocated", true));
            this.allocatedTextBox.Location = new System.Drawing.Point(783, 52);
            this.allocatedTextBox.Name = "allocatedTextBox";
            this.allocatedTextBox.Size = new System.Drawing.Size(200, 20);
            this.allocatedTextBox.TabIndex = 38;
            // 
            // comCodeTextBox
            // 
            this.comCodeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "ComCode", true));
            this.comCodeTextBox.Location = new System.Drawing.Point(451, 229);
            this.comCodeTextBox.Name = "comCodeTextBox";
            this.comCodeTextBox.Size = new System.Drawing.Size(200, 20);
            this.comCodeTextBox.TabIndex = 16;
            // 
            // freeStockTextBox
            // 
            this.freeStockTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "FreeStock", true));
            this.freeStockTextBox.Location = new System.Drawing.Point(783, 78);
            this.freeStockTextBox.Name = "freeStockTextBox";
            this.freeStockTextBox.Size = new System.Drawing.Size(200, 20);
            this.freeStockTextBox.TabIndex = 40;
            // 
            // onOrderTextBox
            // 
            this.onOrderTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "OnOrder", true));
            this.onOrderTextBox.Location = new System.Drawing.Point(783, 104);
            this.onOrderTextBox.Name = "onOrderTextBox";
            this.onOrderTextBox.Size = new System.Drawing.Size(200, 20);
            this.onOrderTextBox.TabIndex = 42;
            // 
            // taxCodeTextBox
            // 
            this.taxCodeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "TaxCode", true));
            this.taxCodeTextBox.Location = new System.Drawing.Point(783, 232);
            this.taxCodeTextBox.Name = "taxCodeTextBox";
            this.taxCodeTextBox.Size = new System.Drawing.Size(200, 20);
            this.taxCodeTextBox.TabIndex = 28;
            // 
            // lastOrderDateDateTimePicker
            // 
            this.lastOrderDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.stockBindingSource, "LastOrderDate", true));
            this.lastOrderDateDateTimePicker.Location = new System.Drawing.Point(783, 130);
            this.lastOrderDateDateTimePicker.Name = "lastOrderDateDateTimePicker";
            this.lastOrderDateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.lastOrderDateDateTimePicker.TabIndex = 44;
            // 
            // departmentTextBox
            // 
            this.departmentTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "Department", true));
            this.departmentTextBox.Location = new System.Drawing.Point(120, 66);
            this.departmentTextBox.Name = "departmentTextBox";
            this.departmentTextBox.Size = new System.Drawing.Size(533, 20);
            this.departmentTextBox.TabIndex = 10;
            // 
            // reOrderDateDateTimePicker
            // 
            this.reOrderDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.stockBindingSource, "ReOrderDate", true));
            this.reOrderDateDateTimePicker.Location = new System.Drawing.Point(783, 156);
            this.reOrderDateDateTimePicker.Name = "reOrderDateDateTimePicker";
            this.reOrderDateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.reOrderDateDateTimePicker.TabIndex = 46;
            // 
            // partNumberTextBox
            // 
            this.partNumberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "PartNumber", true));
            this.partNumberTextBox.Location = new System.Drawing.Point(451, 202);
            this.partNumberTextBox.Name = "partNumberTextBox";
            this.partNumberTextBox.Size = new System.Drawing.Size(200, 20);
            this.partNumberTextBox.TabIndex = 30;
            // 
            // reOrderLevelTextBox
            // 
            this.reOrderLevelTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "ReOrderLevel", true));
            this.reOrderLevelTextBox.Location = new System.Drawing.Point(783, 182);
            this.reOrderLevelTextBox.Name = "reOrderLevelTextBox";
            this.reOrderLevelTextBox.Size = new System.Drawing.Size(200, 20);
            this.reOrderLevelTextBox.TabIndex = 48;
            // 
            // nominalCodeTextBox
            // 
            this.nominalCodeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "NominalCode", true));
            this.nominalCodeTextBox.Location = new System.Drawing.Point(120, 148);
            this.nominalCodeTextBox.Name = "nominalCodeTextBox";
            this.nominalCodeTextBox.Size = new System.Drawing.Size(200, 20);
            this.nominalCodeTextBox.TabIndex = 18;
            // 
            // unitOfSaleTextBox
            // 
            this.unitOfSaleTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "UnitOfSale", true));
            this.unitOfSaleTextBox.Location = new System.Drawing.Point(120, 225);
            this.unitOfSaleTextBox.Name = "unitOfSaleTextBox";
            this.unitOfSaleTextBox.Size = new System.Drawing.Size(200, 20);
            this.unitOfSaleTextBox.TabIndex = 32;
            // 
            // reOrderQtyTextBox
            // 
            this.reOrderQtyTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "ReOrderQty", true));
            this.reOrderQtyTextBox.Location = new System.Drawing.Point(783, 208);
            this.reOrderQtyTextBox.Name = "reOrderQtyTextBox";
            this.reOrderQtyTextBox.Size = new System.Drawing.Size(200, 20);
            this.reOrderQtyTextBox.TabIndex = 50;
            // 
            // productCode
            // 
            this.productCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "ProductCode", true));
            this.productCode.Location = new System.Drawing.Point(120, 14);
            this.productCode.Name = "productCode";
            this.productCode.Size = new System.Drawing.Size(533, 20);
            this.productCode.TabIndex = 6;
            // 
            // costPriceTextBox
            // 
            this.costPriceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "CostPrice", true));
            this.costPriceTextBox.Location = new System.Drawing.Point(120, 253);
            this.costPriceTextBox.Name = "costPriceTextBox";
            this.costPriceTextBox.Size = new System.Drawing.Size(200, 20);
            this.costPriceTextBox.TabIndex = 52;
            // 
            // stockTakeTextBox
            // 
            this.stockTakeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "StockTake", true));
            this.stockTakeTextBox.Location = new System.Drawing.Point(451, 254);
            this.stockTakeTextBox.Name = "stockTakeTextBox";
            this.stockTakeTextBox.Size = new System.Drawing.Size(200, 20);
            this.stockTakeTextBox.TabIndex = 34;
            // 
            // stockTakeQuantityTextBox
            // 
            this.stockTakeQuantityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "StockTakeQuantity", true));
            this.stockTakeQuantityTextBox.Location = new System.Drawing.Point(783, 260);
            this.stockTakeQuantityTextBox.Name = "stockTakeQuantityTextBox";
            this.stockTakeQuantityTextBox.Size = new System.Drawing.Size(200, 20);
            this.stockTakeQuantityTextBox.TabIndex = 54;
            // 
            // locationTextBox
            // 
            this.locationTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "location", true));
            this.locationTextBox.Location = new System.Drawing.Point(120, 118);
            this.locationTextBox.Name = "locationTextBox";
            this.locationTextBox.Size = new System.Drawing.Size(533, 20);
            this.locationTextBox.TabIndex = 14;
            // 
            // supplierAccountTextBox
            // 
            this.supplierAccountTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "SupplierAccount", true));
            this.supplierAccountTextBox.Location = new System.Drawing.Point(120, 174);
            this.supplierAccountTextBox.Name = "supplierAccountTextBox";
            this.supplierAccountTextBox.Size = new System.Drawing.Size(200, 20);
            this.supplierAccountTextBox.TabIndex = 20;
            // 
            // salePriceTextBox
            // 
            this.salePriceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "SalePrice", true));
            this.salePriceTextBox.Location = new System.Drawing.Point(121, 200);
            this.salePriceTextBox.Name = "salePriceTextBox";
            this.salePriceTextBox.Size = new System.Drawing.Size(200, 20);
            this.salePriceTextBox.TabIndex = 22;
            // 
            // descriptionTextBox
            // 
            this.descriptionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "Description", true));
            this.descriptionTextBox.Location = new System.Drawing.Point(120, 40);
            this.descriptionTextBox.Name = "descriptionTextBox";
            this.descriptionTextBox.Size = new System.Drawing.Size(533, 20);
            this.descriptionTextBox.TabIndex = 8;
            // 
            // categoryTextBox
            // 
            this.categoryTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "Category", true));
            this.categoryTextBox.Location = new System.Drawing.Point(120, 92);
            this.categoryTextBox.Name = "categoryTextBox";
            this.categoryTextBox.Size = new System.Drawing.Size(533, 20);
            this.categoryTextBox.TabIndex = 12;
            // 
            // itemTypeTextBox
            // 
            this.itemTypeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockBindingSource, "ItemType", true));
            this.itemTypeTextBox.Location = new System.Drawing.Point(451, 177);
            this.itemTypeTextBox.Name = "itemTypeTextBox";
            this.itemTypeTextBox.Size = new System.Drawing.Size(200, 20);
            this.itemTypeTextBox.TabIndex = 24;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Peru;
            this.panel4.Controls.Add(this.toolStrip1);
            this.panel4.Controls.Add(this.richTextBox1);
            this.panel4.Location = new System.Drawing.Point(1023, 143);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(327, 309);
            this.panel4.TabIndex = 4;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripSeparator1,
            this.toolStripButton2,
            this.toolStripSeparator2,
            this.toolStripButton3,
            this.toolStripSeparator3,
            this.toolStripButton4,
            this.toolStripSeparator4,
            this.toolStripButton5,
            this.toolStripSeparator5,
            this.toolStripButton6,
            this.toolStripSeparator6,
            this.toolStripButton7,
            this.toolStripSeparator7,
            this.lblDate});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(327, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "New";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton2.Text = "Open";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton3.Text = "Save";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton4.Text = "Copy";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton5.Text = "Paste";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton6.Text = "Cut";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton7.Text = "Print";
            this.toolStripButton7.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 25);
            // 
            // lblDate
            // 
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(86, 22);
            this.lblDate.Text = "toolStripLabel1";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(18, 28);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(298, 270);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // stockTableAdapter
            // 
            this.stockTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.InvoiceKombataTableAdapter = null;
            this.tableAdapterManager.LoginTableAdapter = null;
            this.tableAdapterManager.stockTableAdapter = this.stockTableAdapter;
            this.tableAdapterManager.UpdateOrder = LazanoFragrance.kombataDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // stockBindingNavigator
            // 
            this.stockBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.stockBindingNavigator.BindingSource = this.stockBindingSource;
            this.stockBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.stockBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.stockBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.stockBindingNavigatorSaveItem,
            this.toolStripSeparator8,
            this.toolStripTextBox2,
            this.toolStripSeparator9,
            this.toolStripLabel3,
            this.toolStripSeparator10,
            this.cmbSearch1,
            this.toolStripSeparator11,
            this.txtSearch,
            this.toolStripSeparator12,
            this.toolStripButton8});
            this.stockBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.stockBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.stockBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.stockBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.stockBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.stockBindingNavigator.Name = "stockBindingNavigator";
            this.stockBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.stockBindingNavigator.Size = new System.Drawing.Size(1354, 25);
            this.stockBindingNavigator.TabIndex = 5;
            this.stockBindingNavigator.Text = "bindingNavigator1";
            this.stockBindingNavigator.RefreshItems += new System.EventHandler(this.stockBindingNavigator_RefreshItems);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // stockBindingNavigatorSaveItem
            // 
            this.stockBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.stockBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("stockBindingNavigatorSaveItem.Image")));
            this.stockBindingNavigatorSaveItem.Name = "stockBindingNavigatorSaveItem";
            this.stockBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.stockBindingNavigatorSaveItem.Text = "Save Data";
            this.stockBindingNavigatorSaveItem.Click += new System.EventHandler(this.stockBindingNavigatorSaveItem_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox2
            // 
            this.toolStripTextBox2.Name = "toolStripTextBox2";
            this.toolStripTextBox2.Size = new System.Drawing.Size(100, 25);
            this.toolStripTextBox2.Text = "Teller";
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(42, 22);
            this.toolStripLabel3.Text = "Search";
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 25);
            // 
            // cmbSearch1
            // 
            this.cmbSearch1.Name = "cmbSearch1";
            this.cmbSearch1.Size = new System.Drawing.Size(121, 25);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(6, 25);
            // 
            // txtSearch
            // 
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(100, 25);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.Image")));
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton8.Text = "toolStripButton8";
            this.toolStripButton8.Click += new System.EventHandler(this.toolStripButton8_Click);
            // 
            // stockDataGridView
            // 
            this.stockDataGridView.AutoGenerateColumns = false;
            this.stockDataGridView.BackgroundColor = System.Drawing.Color.Peru;
            this.stockDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.stockDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25});
            this.stockDataGridView.DataSource = this.stockBindingSource;
            this.stockDataGridView.GridColor = System.Drawing.Color.Peru;
            this.stockDataGridView.Location = new System.Drawing.Point(12, 458);
            this.stockDataGridView.Name = "stockDataGridView";
            this.stockDataGridView.Size = new System.Drawing.Size(1005, 220);
            this.stockDataGridView.TabIndex = 5;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ProductCode";
            this.dataGridViewTextBoxColumn1.HeaderText = "ProductCode";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Description";
            this.dataGridViewTextBoxColumn2.HeaderText = "Description";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Department";
            this.dataGridViewTextBoxColumn3.HeaderText = "Department";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Category";
            this.dataGridViewTextBoxColumn4.HeaderText = "Category";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "location";
            this.dataGridViewTextBoxColumn5.HeaderText = "location";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "ComCode";
            this.dataGridViewTextBoxColumn6.HeaderText = "ComCode";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "NominalCode";
            this.dataGridViewTextBoxColumn7.HeaderText = "NominalCode";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "SupplierAccount";
            this.dataGridViewTextBoxColumn8.HeaderText = "SupplierAccount";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "SalePrice";
            this.dataGridViewTextBoxColumn9.HeaderText = "SalePrice";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "ItemType";
            this.dataGridViewTextBoxColumn10.HeaderText = "ItemType";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "weight";
            this.dataGridViewTextBoxColumn11.HeaderText = "weight";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "TaxCode";
            this.dataGridViewTextBoxColumn12.HeaderText = "TaxCode";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "PartNumber";
            this.dataGridViewTextBoxColumn13.HeaderText = "PartNumber";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "UnitOfSale";
            this.dataGridViewTextBoxColumn14.HeaderText = "UnitOfSale";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "StockTake";
            this.dataGridViewTextBoxColumn15.HeaderText = "StockTake";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "InStock";
            this.dataGridViewTextBoxColumn16.HeaderText = "InStock";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "Allocated";
            this.dataGridViewTextBoxColumn17.HeaderText = "Allocated";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "FreeStock";
            this.dataGridViewTextBoxColumn18.HeaderText = "FreeStock";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "OnOrder";
            this.dataGridViewTextBoxColumn19.HeaderText = "OnOrder";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "LastOrderDate";
            this.dataGridViewTextBoxColumn20.HeaderText = "LastOrderDate";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "ReOrderDate";
            this.dataGridViewTextBoxColumn21.HeaderText = "ReOrderDate";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "ReOrderLevel";
            this.dataGridViewTextBoxColumn22.HeaderText = "ReOrderLevel";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "ReOrderQty";
            this.dataGridViewTextBoxColumn23.HeaderText = "ReOrderQty";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "CostPrice";
            this.dataGridViewTextBoxColumn24.HeaderText = "CostPrice";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "StockTakeQuantity";
            this.dataGridViewTextBoxColumn25.HeaderText = "StockTakeQuantity";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Peru;
            this.panel5.Controls.Add(this.button7);
            this.panel5.Controls.Add(this.button6);
            this.panel5.Controls.Add(this.button5);
            this.panel5.Controls.Add(this.button4);
            this.panel5.Controls.Add(this.button3);
            this.panel5.Controls.Add(this.button2);
            this.panel5.Controls.Add(this.button1);
            this.panel5.Location = new System.Drawing.Point(1023, 458);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(327, 220);
            this.panel5.TabIndex = 6;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(241, 171);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 30);
            this.button7.TabIndex = 6;
            this.button7.Text = "Back";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(241, 90);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 30);
            this.button6.TabIndex = 5;
            this.button6.Text = "Exit";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(131, 90);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 30);
            this.button5.TabIndex = 4;
            this.button5.Text = "Invoice";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(18, 90);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 30);
            this.button4.TabIndex = 3;
            this.button4.Text = "Report";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(241, 16);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 30);
            this.button3.TabIndex = 2;
            this.button3.Text = "Previous";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(131, 16);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 30);
            this.button2.TabIndex = 1;
            this.button2.Text = "Next";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(18, 16);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 30);
            this.button1.TabIndex = 0;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1354, 689);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.stockDataGridView);
            this.Controls.Add(this.stockBindingNavigator);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kombataDataSet)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockBindingNavigator)).EndInit();
            this.stockBindingNavigator.ResumeLayout(false);
            this.stockBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockDataGridView)).EndInit();
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private kombataDataSet kombataDataSet;
        private System.Windows.Forms.BindingSource stockBindingSource;
        private kombataDataSetTableAdapters.stockTableAdapter stockTableAdapter;
        private kombataDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator stockBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton stockBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox inStockTextBox;
        private System.Windows.Forms.TextBox weightTextBox;
        private System.Windows.Forms.TextBox allocatedTextBox;
        private System.Windows.Forms.TextBox comCodeTextBox;
        private System.Windows.Forms.TextBox freeStockTextBox;
        private System.Windows.Forms.TextBox onOrderTextBox;
        private System.Windows.Forms.TextBox taxCodeTextBox;
        private System.Windows.Forms.DateTimePicker lastOrderDateDateTimePicker;
        private System.Windows.Forms.TextBox departmentTextBox;
        private System.Windows.Forms.DateTimePicker reOrderDateDateTimePicker;
        private System.Windows.Forms.TextBox partNumberTextBox;
        private System.Windows.Forms.TextBox reOrderLevelTextBox;
        private System.Windows.Forms.TextBox nominalCodeTextBox;
        private System.Windows.Forms.TextBox unitOfSaleTextBox;
        private System.Windows.Forms.TextBox reOrderQtyTextBox;
        private System.Windows.Forms.TextBox productCode;
        private System.Windows.Forms.TextBox costPriceTextBox;
        private System.Windows.Forms.TextBox stockTakeTextBox;
        private System.Windows.Forms.TextBox stockTakeQuantityTextBox;
        private System.Windows.Forms.TextBox locationTextBox;
        private System.Windows.Forms.TextBox supplierAccountTextBox;
        private System.Windows.Forms.TextBox salePriceTextBox;
        private System.Windows.Forms.TextBox descriptionTextBox;
        private System.Windows.Forms.TextBox categoryTextBox;
        private System.Windows.Forms.TextBox itemTypeTextBox;
        private System.Windows.Forms.DataGridView stockDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripLabel lblDate;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripComboBox cmbSearch1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox2;
        private System.Windows.Forms.ToolStripTextBox txtSearch;
        private System.Windows.Forms.Button button7;
    }
}
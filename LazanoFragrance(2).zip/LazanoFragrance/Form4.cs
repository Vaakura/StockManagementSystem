﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LazanoFragrance
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void stockBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.stockBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kombataDataSet);

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kombataDataSet.InvoiceKombata' table. You can move, or remove it, as needed.
            this.invoiceKombataTableAdapter.Fill(this.kombataDataSet.InvoiceKombata);
            // TODO: This line of code loads data into the 'kombataDataSet.stock' table. You can move, or remove it, as needed.
            this.stockTableAdapter.Fill(this.kombataDataSet.stock);

        }

        private void invoiceKombataDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.Show();
        
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 f3 = new Form3();
            f3.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Confirm if you want to exit", "Stock Control", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void stockBindingNavigator_RefreshItems(object sender, EventArgs e)
        {
           
            //cmbSearch2.Items.Add("productCode");
           // cmbSearch2.Items.Add("tenderNo");
          
            
        }

        private void cmbSearch2_Click(object sender, EventArgs e)
        {

        }

        private void btnSearch2_Click(object sender, EventArgs e)
        {
/*
            String LazanoFragrance;
            LazanoFragrance = cmbSearch2.Text;
            switch (LazanoFragrance)
            {
                case "tenderNo":
                    this.invoiceKombataBindingSource.Filter = "tenderNo =" + System.Convert.ToString(txtSearch.Text);
                    break;

                case "invoiceNo":
                    this.invoiceKombataBindingSource.Filter = "invoiceNo =" + (txtSearch.Text);
                    break;
             */

            }
        }
    }


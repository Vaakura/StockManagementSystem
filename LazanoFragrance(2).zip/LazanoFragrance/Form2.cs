﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LazanoFragrance
{


    public partial class Form2 : Form
    {
        SqlConnection con = new SqlConnection(@"server = .\SQLEXPRESS; database = Kombata; Integrated Security = true");
        public Form2()
        {
            InitializeComponent();
        }

        private void invoiceKombataBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.invoiceKombataBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kombataDataSet);

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            this.Validate();
            this.invoiceKombataBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kombataDataSet);


            this.invoiceKombataTableAdapter.Fill(this.kombataDataSet.InvoiceKombata);
            lblTime.Text = DateTime.Now.ToLongTimeString();
            lblDate.Text = DateTime.Now.ToLongDateString();


            cmbSearch.Items.Add("tenderNo");
            cmbSearch.Items.Add("invoiceNo");
            


            /*
              int a;

              try
              {
                  //insertInvoic is a stored procedure in sql
                  SqlCommand command = new SqlCommand("InsertInvoiceKombata", con);

                  command.CommandType = CommandType.StoredProcedure;
                  con.Open();
                  String query = "Select Max(InvoiceNo) From InvoiceKombata";
                  command = new SqlCommand(query, con);
                  SqlDataReader dr;
                  dr = command.ExecuteReader();
                  if (dr.Read())
                  {
                      string val = dr[0].ToString();
                      if (val == "")
                      {
                          invoiceNoTextBox.Text = "1";
                      }
                      else
                      {
                          a = Convert.ToInt32(dr[0].ToString());
                          a = a + 1;
                          invoiceNoTextBox.Text = a.ToString();
                      }
                      invoiceKombataDataGridView.Rows.Clear();
                  }
              }
              catch (Exception ex)
              {
                  MessageBox.Show("" + ex);


              }
              finally
              {
                  con.Close();
              }



          }

        



  */
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            /*
            bool Found = false;
            if (invoiceKombataDataGridView.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in invoiceKombataDataGridView.Rows)
                {
                    if (Convert.ToString(row.Cells[0].Value) == descriptionTextBox.Text && (Convert.ToString(row.Cells[18].Value) == unitPriceTextBox.Text) && (Convert.ToString(row.Cells[20].Value) == unitPriceTextBox.Text))
                    {
                        row.Cells[2].Value = Convert.ToString(1 + Convert.ToInt16(row.Cells[2].Value));
                        Found = true;
                    }
                }
                if (!Found)
                {
                    invoiceKombataDataGridView.Rows.Add(descriptionTextBox.Text, unitPriceTextBox.Text, 1);
                }
            }
            else
            {
                invoiceKombataDataGridView.Rows.Add(descriptionTextBox.Text, unitPriceTextBox.Text, 1);
            }


            //amount = price * qty



            foreach (DataGridViewRow row in invoiceKombataDataGridView.Rows)
            {

                row.Cells[invoiceKombataDataGridView.Columns[22].Index].Value = (Convert.ToDouble(row.Cells[invoiceKombataDataGridView.Columns[20].Index].Value) * Convert.ToDouble(row.Cells[invoiceKombataDataGridView.Columns[21].Index].Value));
            }
            //total qty
            int sum = 0;
            for (int i = 0; i < invoiceKombataDataGridView.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(invoiceKombataDataGridView.Rows[i].Cells[2].Value);
            }

            descriptionTextBox.Text = "";
            unitPriceTextBox.Text = "";

            descriptionTextBox.Focus();

            quantityTextBox.Text = sum.ToString();

            //total amount
            int sum1 = 0;
            for (int i = 0; i < invoiceKombataDataGridView.Rows.Count; ++i)
            {
                sum1 += Convert.ToInt32(invoiceKombataDataGridView.Rows[i].Cells[3].Value);
            }

            descriptionTextBox.Text = "";
            unitPriceTextBox.Text = "";

            descriptionTextBox.Focus();

            amountTextBox.Text = sum1.ToString();

            */


        }

        private void invoiceKombataDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           /* int row = 0;
            row = invoiceKombataDataGridView.Rows.Count - 1 ;
            invoiceKombataDataGridView["dataGridViewTextBoxColumn18", row].Value = invoiceNoTextBox.Text;
            invoiceKombataDataGridView.Refresh();
            */

        }

        private void btnSaveInvoice_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.invoiceKombataBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kombataDataSet);


            rtfReceipt.AppendText(Environment.NewLine);
            rtfReceipt.AppendText("................................................................................................." + Environment.NewLine);
            rtfReceipt.AppendText("                         LAZANAO FRAGRANCE                                 " + Environment.NewLine);
            rtfReceipt.AppendText(".................................................................................................." + Environment.NewLine);
            rtfReceipt.AppendText("................................................................................................." + Environment.NewLine);
            rtfReceipt.AppendText("  P.O BOX 875                                  " + Environment.NewLine);
            rtfReceipt.AppendText("  OYJTOMUISE                                  " + Environment.NewLine);
            rtfReceipt.AppendText("  WINDHOEK                                  " + Environment.NewLine);
            rtfReceipt.AppendText(".................................................................................................." + Environment.NewLine);
            rtfReceipt.AppendText("Descripion: " + "\t" + descriptionTextBox.Text + Environment.NewLine);
            rtfReceipt.AppendText("Department: " + "\t" + departmentTextBox.Text + Environment.NewLine);
            rtfReceipt.AppendText("Tendor: " + "\t" + tenderNoTextBox.Text + Environment.NewLine);
            rtfReceipt.AppendText("Quantity: " + "\t" + quantityTextBox.Text + Environment.NewLine);
            rtfReceipt.AppendText("invoiceNo: " + "\t" + invoiceNoTextBox.Text + Environment.NewLine);
            rtfReceipt.AppendText("received by: " + "\t" + recievedByTextBox.Text + Environment.NewLine);
            rtfReceipt.AppendText(Environment.NewLine);
            rtfReceipt.AppendText("..................................................................................................");
            rtfReceipt.AppendText(lblDate.Text + "\t"  + Environment.NewLine);
            rtfReceipt.AppendText(lblTime.Text + "\t" + Environment.NewLine);


            /* SqlCommand command = new SqlCommand("InsertInvoiceKombata", con);
            
            
            

         command.CommandType = CommandType.StoredProcedure;
            
            
         for (int i = 0; i < invoiceKombataDataGridView.Rows.Count; i++)
         {
             command.Parameters.Add(new SqlParameter("@Name", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn1"].Value));
             command.Parameters.Add(new SqlParameter("@City", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn2"].Value));
             command.Parameters.Add(new SqlParameter("@Tell", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn3"].Value));
             command.Parameters.Add(new SqlParameter("@VatNo", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn4"].Value));
             command.Parameters.Add(new SqlParameter("@Bank", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn5"].Value));
             command.Parameters.Add(new SqlParameter("@AccNo", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn6"].Value));
             command.Parameters.Add(new SqlParameter("@AccName", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn7"].Value));
             command.Parameters.Add(new SqlParameter("@Name1", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn8"].Value));
             command.Parameters.Add(new SqlParameter("@City1", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn9"].Value));
             command.Parameters.Add(new SqlParameter("@Tell1", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn10"].Value));
             command.Parameters.Add(new SqlParameter("@VatNo1", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn11"].Value));
             command.Parameters.Add(new SqlParameter("@Bank1", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn12"].Value));
             command.Parameters.Add(new SqlParameter("@AccNo1", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn13"].Value));
             command.Parameters.Add(new SqlParameter("@AccName1", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn14"].Value));
             command.Parameters.Add(new SqlParameter("@TendorNo", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn15"].Value));
             command.Parameters.Add(new SqlParameter("@InvoiceNo", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn16"].Value));
             command.Parameters.Add(new SqlParameter("@Description", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn17"].Value));
             command.Parameters.Add(new SqlParameter("@Department", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn18"].Value));
             command.Parameters.Add(new SqlParameter("@unitPrice", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn19"].Value));
             command.Parameters.Add(new SqlParameter("@Quantity", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn20"].Value));
             command.Parameters.Add(new SqlParameter("@Amount", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn21"].Value));
             command.Parameters.Add(new SqlParameter("@Date", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn22"].Value));
             command.Parameters.Add(new SqlParameter("@RecievedBy", invoiceKombataDataGridView.Rows[i].Cells["dataGridViewTextBoxColumn23"].Value));

             con.Open();
             command.ExecuteNonQuery();
             MessageBox.Show("Invoice succesfully saved");
             con.Close();
            

         }
        
             int a;



             String query = "Select Max(InvoiceNo) From KombataInvoice";
             SqlDataReader dr;
             con.Open(); command = new SqlCommand(query, con);
             dr = command.ExecuteReader();
             if (dr.Read())
             {

                 string val = dr[0].ToString();
                 if (val == "")
                 {
                     invoiceNoTextBox.Text = "1";
                 }
                 else
                 {
                     a = Convert.ToInt32(dr[0].ToString());
                     a = a + 1;
                     invoiceNoTextBox.Text = a.ToString();
                 }
                 con.Close();
             }

             invoiceKombataDataGridView.Rows.Clear();
             
         }
         */
        }
        private void invoiceKombataBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {

            String LazanoFragrance;
            LazanoFragrance = cmbSearch.Text;
             switch (LazanoFragrance )
            {
                case "tenderNo":
                    this.invoiceKombataBindingSource.Filter = "tenderNo =" + System.Convert.ToString(txtSearch.Text);
                    break;

                case "invoiceNo":
                    this.invoiceKombataBindingSource.Filter = "invoiceNo =" + (txtSearch.Text);
                    break;
                case "invoiceNoTextBox":
                    this.invoiceKombataBindingSource.Filter = "invoiceNoTextBox =" + System.Convert.ToString(txtSearch.Text);
                    break;
          
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Confirm if you want to exit", "Stock Control", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFile = new SaveFileDialog();

            saveFile.FileName = "Notepad Text";
            saveFile.Filter = "Text Files(*.txt)|*.txt|All files(*.*)|*.*";

            if (saveFile.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {

                using (System.IO.StreamWriter sw = new System.IO.StreamWriter(saveFile.FileName))
                    sw.WriteLine(rtfReceipt.Text);
            }

        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfile = new OpenFileDialog();

            openfile.Filter = "Text Files(*.txt)|*.txt|All files(*.*)|*.*";

            if (openfile.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                rtfReceipt.LoadFile(openfile.FileName, RichTextBoxStreamType.PlainText);

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            rtfReceipt.Clear();
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            rtfReceipt.Copy();
        }

        private void btnPaste_Click(object sender, EventArgs e)
        {
            rtfReceipt.Paste();

        }

        private void btnCut_Click(object sender, EventArgs e)
        {

            rtfReceipt.Cut();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(rtfReceipt.Text, new Font("Arial", 20, FontStyle.Regular), Brushes.Black, 120, 120);

        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            this.invoiceKombataBindingSource.MoveNext();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            this.invoiceKombataBindingSource.MovePrevious();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            this.invoiceKombataBindingSource.RemoveCurrent();

        }

        private void txtSearch_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void rtfReceipt_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        }

        }
    

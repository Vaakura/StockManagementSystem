﻿namespace LazanoFragrance
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label addressLabel;
            System.Windows.Forms.Label cityLabel;
            System.Windows.Forms.Label telLabel;
            System.Windows.Forms.Label vatNoLabel;
            System.Windows.Forms.Label bankLabel;
            System.Windows.Forms.Label accNoLabel;
            System.Windows.Forms.Label accNameLabel;
            System.Windows.Forms.Label name1Label;
            System.Windows.Forms.Label address1Label;
            System.Windows.Forms.Label city1Label;
            System.Windows.Forms.Label tel1Label;
            System.Windows.Forms.Label vatNo1Label;
            System.Windows.Forms.Label bank1Label;
            System.Windows.Forms.Label accNo1Label;
            System.Windows.Forms.Label accName1Label;
            System.Windows.Forms.Label tenderNoLabel;
            System.Windows.Forms.Label invoiceNoLabel;
            System.Windows.Forms.Label descriptionLabel;
            System.Windows.Forms.Label departmentLabel;
            System.Windows.Forms.Label unitPriceLabel;
            System.Windows.Forms.Label quantityLabel;
            System.Windows.Forms.Label amountLabel;
            System.Windows.Forms.Label dateLabel;
            System.Windows.Forms.Label recievedByLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.vatNoTextBox = new System.Windows.Forms.TextBox();
            this.invoiceKombataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kombataDataSet = new LazanoFragrance.kombataDataSet();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.bankTextBox = new System.Windows.Forms.TextBox();
            this.telTextBox = new System.Windows.Forms.TextBox();
            this.accNoTextBox = new System.Windows.Forms.TextBox();
            this.accNameTextBox = new System.Windows.Forms.TextBox();
            this.cityTextBox = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.vatNo1TextBox = new System.Windows.Forms.TextBox();
            this.city1TextBox = new System.Windows.Forms.TextBox();
            this.bank1TextBox = new System.Windows.Forms.TextBox();
            this.name1TextBox = new System.Windows.Forms.TextBox();
            this.accNo1TextBox = new System.Windows.Forms.TextBox();
            this.address1TextBox = new System.Windows.Forms.TextBox();
            this.accName1TextBox = new System.Windows.Forms.TextBox();
            this.tel1TextBox = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnNew = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnSave = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnOpen = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.btnCopy = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.btnPaste = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.btnCut = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.btnPrint = new System.Windows.Forms.ToolStripButton();
            this.lblDate = new System.Windows.Forms.ToolStripLabel();
            this.rtfReceipt = new System.Windows.Forms.RichTextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.unitPriceTextBox = new System.Windows.Forms.TextBox();
            this.tenderNoTextBox = new System.Windows.Forms.TextBox();
            this.quantityTextBox = new System.Windows.Forms.TextBox();
            this.invoiceNoTextBox = new System.Windows.Forms.TextBox();
            this.amountTextBox = new System.Windows.Forms.TextBox();
            this.departmentTextBox = new System.Windows.Forms.TextBox();
            this.descriptionTextBox = new System.Windows.Forms.TextBox();
            this.dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.recievedByTextBox = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnSaveInvoice = new System.Windows.Forms.Button();
            this.invoiceKombataTableAdapter = new LazanoFragrance.kombataDataSetTableAdapters.InvoiceKombataTableAdapter();
            this.tableAdapterManager = new LazanoFragrance.kombataDataSetTableAdapters.TableAdapterManager();
            this.invoiceKombataBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.invoiceKombataBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.LOGEDIN = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.cmbSearch = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.txtSearch = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.btnSearch = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.lblTime = new System.Windows.Forms.ToolStripLabel();
            this.invoiceKombataDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.button1 = new System.Windows.Forms.Button();
            nameLabel = new System.Windows.Forms.Label();
            addressLabel = new System.Windows.Forms.Label();
            cityLabel = new System.Windows.Forms.Label();
            telLabel = new System.Windows.Forms.Label();
            vatNoLabel = new System.Windows.Forms.Label();
            bankLabel = new System.Windows.Forms.Label();
            accNoLabel = new System.Windows.Forms.Label();
            accNameLabel = new System.Windows.Forms.Label();
            name1Label = new System.Windows.Forms.Label();
            address1Label = new System.Windows.Forms.Label();
            city1Label = new System.Windows.Forms.Label();
            tel1Label = new System.Windows.Forms.Label();
            vatNo1Label = new System.Windows.Forms.Label();
            bank1Label = new System.Windows.Forms.Label();
            accNo1Label = new System.Windows.Forms.Label();
            accName1Label = new System.Windows.Forms.Label();
            tenderNoLabel = new System.Windows.Forms.Label();
            invoiceNoLabel = new System.Windows.Forms.Label();
            descriptionLabel = new System.Windows.Forms.Label();
            departmentLabel = new System.Windows.Forms.Label();
            unitPriceLabel = new System.Windows.Forms.Label();
            quantityLabel = new System.Windows.Forms.Label();
            amountLabel = new System.Windows.Forms.Label();
            dateLabel = new System.Windows.Forms.Label();
            recievedByLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceKombataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kombataDataSet)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceKombataBindingNavigator)).BeginInit();
            this.invoiceKombataBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceKombataDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(9, 6);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(38, 13);
            nameLabel.TabIndex = 10;
            nameLabel.Text = "Name:";
            // 
            // addressLabel
            // 
            addressLabel.AutoSize = true;
            addressLabel.Location = new System.Drawing.Point(9, 49);
            addressLabel.Name = "addressLabel";
            addressLabel.Size = new System.Drawing.Size(48, 13);
            addressLabel.TabIndex = 12;
            addressLabel.Text = "Address:";
            // 
            // cityLabel
            // 
            cityLabel.AutoSize = true;
            cityLabel.Location = new System.Drawing.Point(9, 88);
            cityLabel.Name = "cityLabel";
            cityLabel.Size = new System.Drawing.Size(27, 13);
            cityLabel.TabIndex = 14;
            cityLabel.Text = "City:";
            // 
            // telLabel
            // 
            telLabel.AutoSize = true;
            telLabel.Location = new System.Drawing.Point(9, 124);
            telLabel.Name = "telLabel";
            telLabel.Size = new System.Drawing.Size(25, 13);
            telLabel.TabIndex = 16;
            telLabel.Text = "Tel:";
            // 
            // vatNoLabel
            // 
            vatNoLabel.AutoSize = true;
            vatNoLabel.Location = new System.Drawing.Point(178, 9);
            vatNoLabel.Name = "vatNoLabel";
            vatNoLabel.Size = new System.Drawing.Size(43, 13);
            vatNoLabel.TabIndex = 18;
            vatNoLabel.Text = "Vat No:";
            // 
            // bankLabel
            // 
            bankLabel.AutoSize = true;
            bankLabel.Location = new System.Drawing.Point(178, 49);
            bankLabel.Name = "bankLabel";
            bankLabel.Size = new System.Drawing.Size(35, 13);
            bankLabel.TabIndex = 20;
            bankLabel.Text = "Bank:";
            // 
            // accNoLabel
            // 
            accNoLabel.AutoSize = true;
            accNoLabel.Location = new System.Drawing.Point(178, 84);
            accNoLabel.Name = "accNoLabel";
            accNoLabel.Size = new System.Drawing.Size(46, 13);
            accNoLabel.TabIndex = 22;
            accNoLabel.Text = "Acc No:";
            // 
            // accNameLabel
            // 
            accNameLabel.AutoSize = true;
            accNameLabel.Location = new System.Drawing.Point(180, 121);
            accNameLabel.Name = "accNameLabel";
            accNameLabel.Size = new System.Drawing.Size(60, 13);
            accNameLabel.TabIndex = 24;
            accNameLabel.Text = "Acc Name:";
            // 
            // name1Label
            // 
            name1Label.AutoSize = true;
            name1Label.Location = new System.Drawing.Point(5, 9);
            name1Label.Name = "name1Label";
            name1Label.Size = new System.Drawing.Size(44, 13);
            name1Label.TabIndex = 26;
            name1Label.Text = "Name1:";
            // 
            // address1Label
            // 
            address1Label.AutoSize = true;
            address1Label.Location = new System.Drawing.Point(5, 45);
            address1Label.Name = "address1Label";
            address1Label.Size = new System.Drawing.Size(54, 13);
            address1Label.TabIndex = 28;
            address1Label.Text = "Address1:";
            // 
            // city1Label
            // 
            city1Label.AutoSize = true;
            city1Label.Location = new System.Drawing.Point(5, 87);
            city1Label.Name = "city1Label";
            city1Label.Size = new System.Drawing.Size(33, 13);
            city1Label.TabIndex = 30;
            city1Label.Text = "City1:";
            // 
            // tel1Label
            // 
            tel1Label.AutoSize = true;
            tel1Label.Location = new System.Drawing.Point(5, 121);
            tel1Label.Name = "tel1Label";
            tel1Label.Size = new System.Drawing.Size(31, 13);
            tel1Label.TabIndex = 32;
            tel1Label.Text = "Tel1:";
            // 
            // vatNo1Label
            // 
            vatNo1Label.AutoSize = true;
            vatNo1Label.Location = new System.Drawing.Point(182, 12);
            vatNo1Label.Name = "vatNo1Label";
            vatNo1Label.Size = new System.Drawing.Size(49, 13);
            vatNo1Label.TabIndex = 34;
            vatNo1Label.Text = "Vat No1:";
            // 
            // bank1Label
            // 
            bank1Label.AutoSize = true;
            bank1Label.Location = new System.Drawing.Point(182, 46);
            bank1Label.Name = "bank1Label";
            bank1Label.Size = new System.Drawing.Size(41, 13);
            bank1Label.TabIndex = 36;
            bank1Label.Text = "Bank1:";
            // 
            // accNo1Label
            // 
            accNo1Label.AutoSize = true;
            accNo1Label.Location = new System.Drawing.Point(182, 90);
            accNo1Label.Name = "accNo1Label";
            accNo1Label.Size = new System.Drawing.Size(52, 13);
            accNo1Label.TabIndex = 38;
            accNo1Label.Text = "Acc No1:";
            // 
            // accName1Label
            // 
            accName1Label.AutoSize = true;
            accName1Label.Location = new System.Drawing.Point(167, 122);
            accName1Label.Name = "accName1Label";
            accName1Label.Size = new System.Drawing.Size(66, 13);
            accName1Label.TabIndex = 40;
            accName1Label.Text = "Acc Name1:";
            // 
            // tenderNoLabel
            // 
            tenderNoLabel.AutoSize = true;
            tenderNoLabel.Location = new System.Drawing.Point(11, 120);
            tenderNoLabel.Name = "tenderNoLabel";
            tenderNoLabel.Size = new System.Drawing.Size(61, 13);
            tenderNoLabel.TabIndex = 42;
            tenderNoLabel.Text = "Tender No:";
            // 
            // invoiceNoLabel
            // 
            invoiceNoLabel.AutoSize = true;
            invoiceNoLabel.Location = new System.Drawing.Point(483, 21);
            invoiceNoLabel.Name = "invoiceNoLabel";
            invoiceNoLabel.Size = new System.Drawing.Size(62, 13);
            invoiceNoLabel.TabIndex = 44;
            invoiceNoLabel.Text = "Invoice No:";
            // 
            // descriptionLabel
            // 
            descriptionLabel.AutoSize = true;
            descriptionLabel.Location = new System.Drawing.Point(11, 18);
            descriptionLabel.Name = "descriptionLabel";
            descriptionLabel.Size = new System.Drawing.Size(63, 13);
            descriptionLabel.TabIndex = 46;
            descriptionLabel.Text = "Description:";
            // 
            // departmentLabel
            // 
            departmentLabel.AutoSize = true;
            departmentLabel.Location = new System.Drawing.Point(11, 68);
            departmentLabel.Name = "departmentLabel";
            departmentLabel.Size = new System.Drawing.Size(65, 13);
            departmentLabel.TabIndex = 48;
            departmentLabel.Text = "Department:";
            // 
            // unitPriceLabel
            // 
            unitPriceLabel.AutoSize = true;
            unitPriceLabel.Location = new System.Drawing.Point(257, 21);
            unitPriceLabel.Name = "unitPriceLabel";
            unitPriceLabel.Size = new System.Drawing.Size(54, 13);
            unitPriceLabel.TabIndex = 50;
            unitPriceLabel.Text = "unit Price:";
            // 
            // quantityLabel
            // 
            quantityLabel.AutoSize = true;
            quantityLabel.Location = new System.Drawing.Point(257, 71);
            quantityLabel.Name = "quantityLabel";
            quantityLabel.Size = new System.Drawing.Size(49, 13);
            quantityLabel.TabIndex = 52;
            quantityLabel.Text = "Quantity:";
            // 
            // amountLabel
            // 
            amountLabel.AutoSize = true;
            amountLabel.Location = new System.Drawing.Point(257, 123);
            amountLabel.Name = "amountLabel";
            amountLabel.Size = new System.Drawing.Size(46, 13);
            amountLabel.TabIndex = 54;
            amountLabel.Text = "Amount:";
            // 
            // dateLabel
            // 
            dateLabel.AutoSize = true;
            dateLabel.Location = new System.Drawing.Point(480, 127);
            dateLabel.Name = "dateLabel";
            dateLabel.Size = new System.Drawing.Size(33, 13);
            dateLabel.TabIndex = 56;
            dateLabel.Text = "Date:";
            // 
            // recievedByLabel
            // 
            recievedByLabel.AutoSize = true;
            recievedByLabel.Location = new System.Drawing.Point(480, 71);
            recievedByLabel.Name = "recievedByLabel";
            recievedByLabel.Size = new System.Drawing.Size(66, 13);
            recievedByLabel.TabIndex = 58;
            recievedByLabel.Text = "recieved By:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Peru;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1145, 74);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(210, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(576, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "LAZANAO FINANCE DEPARTMENT";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Peru;
            this.panel2.Controls.Add(vatNoLabel);
            this.panel2.Controls.Add(nameLabel);
            this.panel2.Controls.Add(this.vatNoTextBox);
            this.panel2.Controls.Add(this.addressTextBox);
            this.panel2.Controls.Add(bankLabel);
            this.panel2.Controls.Add(this.nameTextBox);
            this.panel2.Controls.Add(this.bankTextBox);
            this.panel2.Controls.Add(accNoLabel);
            this.panel2.Controls.Add(this.telTextBox);
            this.panel2.Controls.Add(this.accNoTextBox);
            this.panel2.Controls.Add(addressLabel);
            this.panel2.Controls.Add(accNameLabel);
            this.panel2.Controls.Add(telLabel);
            this.panel2.Controls.Add(this.accNameTextBox);
            this.panel2.Controls.Add(this.cityTextBox);
            this.panel2.Controls.Add(cityLabel);
            this.panel2.Location = new System.Drawing.Point(12, 140);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(358, 149);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // vatNoTextBox
            // 
            this.vatNoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "VatNo", true));
            this.vatNoTextBox.Location = new System.Drawing.Point(250, 6);
            this.vatNoTextBox.Name = "vatNoTextBox";
            this.vatNoTextBox.Size = new System.Drawing.Size(100, 20);
            this.vatNoTextBox.TabIndex = 19;
            // 
            // invoiceKombataBindingSource
            // 
            this.invoiceKombataBindingSource.DataMember = "InvoiceKombata";
            this.invoiceKombataBindingSource.DataSource = this.kombataDataSet;
            // 
            // kombataDataSet
            // 
            this.kombataDataSet.DataSetName = "kombataDataSet";
            this.kombataDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // addressTextBox
            // 
            this.addressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "Address", true));
            this.addressTextBox.Location = new System.Drawing.Point(59, 46);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(109, 20);
            this.addressTextBox.TabIndex = 13;
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "Name", true));
            this.nameTextBox.Location = new System.Drawing.Point(59, 3);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(109, 20);
            this.nameTextBox.TabIndex = 11;
            // 
            // bankTextBox
            // 
            this.bankTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "Bank", true));
            this.bankTextBox.Location = new System.Drawing.Point(250, 46);
            this.bankTextBox.Name = "bankTextBox";
            this.bankTextBox.Size = new System.Drawing.Size(100, 20);
            this.bankTextBox.TabIndex = 21;
            // 
            // telTextBox
            // 
            this.telTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "Tel", true));
            this.telTextBox.Location = new System.Drawing.Point(59, 121);
            this.telTextBox.Name = "telTextBox";
            this.telTextBox.Size = new System.Drawing.Size(109, 20);
            this.telTextBox.TabIndex = 17;
            // 
            // accNoTextBox
            // 
            this.accNoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "AccNo", true));
            this.accNoTextBox.Location = new System.Drawing.Point(250, 81);
            this.accNoTextBox.Name = "accNoTextBox";
            this.accNoTextBox.Size = new System.Drawing.Size(100, 20);
            this.accNoTextBox.TabIndex = 23;
            // 
            // accNameTextBox
            // 
            this.accNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "AccName", true));
            this.accNameTextBox.Location = new System.Drawing.Point(250, 118);
            this.accNameTextBox.Name = "accNameTextBox";
            this.accNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.accNameTextBox.TabIndex = 25;
            // 
            // cityTextBox
            // 
            this.cityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "City", true));
            this.cityTextBox.Location = new System.Drawing.Point(59, 85);
            this.cityTextBox.Name = "cityTextBox";
            this.cityTextBox.Size = new System.Drawing.Size(109, 20);
            this.cityTextBox.TabIndex = 15;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Peru;
            this.panel3.Controls.Add(vatNo1Label);
            this.panel3.Controls.Add(city1Label);
            this.panel3.Controls.Add(this.vatNo1TextBox);
            this.panel3.Controls.Add(name1Label);
            this.panel3.Controls.Add(bank1Label);
            this.panel3.Controls.Add(this.city1TextBox);
            this.panel3.Controls.Add(this.bank1TextBox);
            this.panel3.Controls.Add(this.name1TextBox);
            this.panel3.Controls.Add(accNo1Label);
            this.panel3.Controls.Add(tel1Label);
            this.panel3.Controls.Add(this.accNo1TextBox);
            this.panel3.Controls.Add(accName1Label);
            this.panel3.Controls.Add(this.address1TextBox);
            this.panel3.Controls.Add(this.accName1TextBox);
            this.panel3.Controls.Add(this.tel1TextBox);
            this.panel3.Controls.Add(address1Label);
            this.panel3.Location = new System.Drawing.Point(401, 140);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(363, 149);
            this.panel3.TabIndex = 2;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // vatNo1TextBox
            // 
            this.vatNo1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "VatNo1", true));
            this.vatNo1TextBox.Location = new System.Drawing.Point(237, 9);
            this.vatNo1TextBox.Name = "vatNo1TextBox";
            this.vatNo1TextBox.Size = new System.Drawing.Size(112, 20);
            this.vatNo1TextBox.TabIndex = 35;
            // 
            // city1TextBox
            // 
            this.city1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "City1", true));
            this.city1TextBox.Location = new System.Drawing.Point(58, 85);
            this.city1TextBox.Name = "city1TextBox";
            this.city1TextBox.Size = new System.Drawing.Size(105, 20);
            this.city1TextBox.TabIndex = 31;
            // 
            // bank1TextBox
            // 
            this.bank1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "Bank1", true));
            this.bank1TextBox.Location = new System.Drawing.Point(239, 43);
            this.bank1TextBox.Name = "bank1TextBox";
            this.bank1TextBox.Size = new System.Drawing.Size(112, 20);
            this.bank1TextBox.TabIndex = 37;
            // 
            // name1TextBox
            // 
            this.name1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "Name1", true));
            this.name1TextBox.Location = new System.Drawing.Point(58, 7);
            this.name1TextBox.Name = "name1TextBox";
            this.name1TextBox.Size = new System.Drawing.Size(105, 20);
            this.name1TextBox.TabIndex = 27;
            // 
            // accNo1TextBox
            // 
            this.accNo1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "AccNo1", true));
            this.accNo1TextBox.Location = new System.Drawing.Point(239, 85);
            this.accNo1TextBox.Name = "accNo1TextBox";
            this.accNo1TextBox.Size = new System.Drawing.Size(112, 20);
            this.accNo1TextBox.TabIndex = 39;
            // 
            // address1TextBox
            // 
            this.address1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "Address1", true));
            this.address1TextBox.Location = new System.Drawing.Point(58, 43);
            this.address1TextBox.Name = "address1TextBox";
            this.address1TextBox.Size = new System.Drawing.Size(105, 20);
            this.address1TextBox.TabIndex = 29;
            // 
            // accName1TextBox
            // 
            this.accName1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "AccName1", true));
            this.accName1TextBox.Location = new System.Drawing.Point(239, 119);
            this.accName1TextBox.Name = "accName1TextBox";
            this.accName1TextBox.Size = new System.Drawing.Size(110, 20);
            this.accName1TextBox.TabIndex = 41;
            // 
            // tel1TextBox
            // 
            this.tel1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "Tel1", true));
            this.tel1TextBox.Location = new System.Drawing.Point(58, 119);
            this.tel1TextBox.Name = "tel1TextBox";
            this.tel1TextBox.Size = new System.Drawing.Size(105, 20);
            this.tel1TextBox.TabIndex = 33;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Peru;
            this.panel4.Controls.Add(this.label3);
            this.panel4.Location = new System.Drawing.Point(12, 92);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(358, 39);
            this.panel4.TabIndex = 3;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(65, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(199, 29);
            this.label3.TabIndex = 2;
            this.label3.Text = "INVOICE FROM";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Peru;
            this.panel5.Controls.Add(this.label4);
            this.panel5.Location = new System.Drawing.Point(401, 92);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(363, 39);
            this.panel5.TabIndex = 4;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(92, 5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(161, 29);
            this.label4.TabIndex = 2;
            this.label4.Text = "INVOICE TO";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Peru;
            this.panel6.Controls.Add(this.toolStrip1);
            this.panel6.Controls.Add(this.rtfReceipt);
            this.panel6.Location = new System.Drawing.Point(783, 92);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(374, 406);
            this.panel6.TabIndex = 5;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNew,
            this.toolStripSeparator1,
            this.btnSave,
            this.toolStripSeparator2,
            this.btnOpen,
            this.toolStripSeparator3,
            this.btnCopy,
            this.toolStripSeparator4,
            this.btnPaste,
            this.toolStripSeparator5,
            this.btnCut,
            this.toolStripSeparator6,
            this.btnPrint,
            this.lblDate});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(374, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnNew
            // 
            this.btnNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnNew.Image = ((System.Drawing.Image)(resources.GetObject("btnNew.Image")));
            this.btnNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(23, 22);
            this.btnNew.Text = "New";
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // btnSave
            // 
            this.btnSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(23, 22);
            this.btnSave.Text = "Save";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // btnOpen
            // 
            this.btnOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnOpen.Image = ((System.Drawing.Image)(resources.GetObject("btnOpen.Image")));
            this.btnOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(23, 22);
            this.btnOpen.Text = "Open";
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // btnCopy
            // 
            this.btnCopy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnCopy.Image = ((System.Drawing.Image)(resources.GetObject("btnCopy.Image")));
            this.btnCopy.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(23, 22);
            this.btnCopy.Text = "Copy";
            this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // btnPaste
            // 
            this.btnPaste.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnPaste.Image = ((System.Drawing.Image)(resources.GetObject("btnPaste.Image")));
            this.btnPaste.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPaste.Name = "btnPaste";
            this.btnPaste.Size = new System.Drawing.Size(23, 22);
            this.btnPaste.Text = "Paste";
            this.btnPaste.Click += new System.EventHandler(this.btnPaste_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // btnCut
            // 
            this.btnCut.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnCut.Image = ((System.Drawing.Image)(resources.GetObject("btnCut.Image")));
            this.btnCut.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCut.Name = "btnCut";
            this.btnCut.Size = new System.Drawing.Size(23, 22);
            this.btnCut.Text = "Cut";
            this.btnCut.Click += new System.EventHandler(this.btnCut_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // btnPrint
            // 
            this.btnPrint.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnPrint.Image = ((System.Drawing.Image)(resources.GetObject("btnPrint.Image")));
            this.btnPrint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(23, 22);
            this.btnPrint.Text = "Print";
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // lblDate
            // 
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(86, 22);
            this.lblDate.Text = "toolStripLabel3";
            // 
            // rtfReceipt
            // 
            this.rtfReceipt.Location = new System.Drawing.Point(20, 38);
            this.rtfReceipt.Name = "rtfReceipt";
            this.rtfReceipt.Size = new System.Drawing.Size(336, 353);
            this.rtfReceipt.TabIndex = 0;
            this.rtfReceipt.Text = "";
            this.rtfReceipt.TextChanged += new System.EventHandler(this.rtfReceipt_TextChanged);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Peru;
            this.panel7.Controls.Add(this.label2);
            this.panel7.Location = new System.Drawing.Point(12, 295);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(752, 39);
            this.panel7.TabIndex = 6;
            this.panel7.Paint += new System.Windows.Forms.PaintEventHandler(this.panel7_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(321, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "INVOICE";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Peru;
            this.panel8.Controls.Add(tenderNoLabel);
            this.panel8.Controls.Add(this.unitPriceTextBox);
            this.panel8.Controls.Add(this.tenderNoTextBox);
            this.panel8.Controls.Add(this.quantityTextBox);
            this.panel8.Controls.Add(invoiceNoLabel);
            this.panel8.Controls.Add(quantityLabel);
            this.panel8.Controls.Add(this.invoiceNoTextBox);
            this.panel8.Controls.Add(unitPriceLabel);
            this.panel8.Controls.Add(amountLabel);
            this.panel8.Controls.Add(descriptionLabel);
            this.panel8.Controls.Add(this.amountTextBox);
            this.panel8.Controls.Add(this.departmentTextBox);
            this.panel8.Controls.Add(dateLabel);
            this.panel8.Controls.Add(this.descriptionTextBox);
            this.panel8.Controls.Add(this.dateDateTimePicker);
            this.panel8.Controls.Add(recievedByLabel);
            this.panel8.Controls.Add(departmentLabel);
            this.panel8.Controls.Add(this.recievedByTextBox);
            this.panel8.Location = new System.Drawing.Point(12, 340);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(752, 158);
            this.panel8.TabIndex = 7;
            this.panel8.Paint += new System.Windows.Forms.PaintEventHandler(this.panel8_Paint);
            // 
            // unitPriceTextBox
            // 
            this.unitPriceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "unitPrice", true));
            this.unitPriceTextBox.Location = new System.Drawing.Point(329, 18);
            this.unitPriceTextBox.Name = "unitPriceTextBox";
            this.unitPriceTextBox.Size = new System.Drawing.Size(109, 20);
            this.unitPriceTextBox.TabIndex = 51;
            // 
            // tenderNoTextBox
            // 
            this.tenderNoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "TenderNo", true));
            this.tenderNoTextBox.Location = new System.Drawing.Point(83, 117);
            this.tenderNoTextBox.Name = "tenderNoTextBox";
            this.tenderNoTextBox.Size = new System.Drawing.Size(109, 20);
            this.tenderNoTextBox.TabIndex = 43;
            // 
            // quantityTextBox
            // 
            this.quantityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "Quantity", true));
            this.quantityTextBox.Location = new System.Drawing.Point(329, 68);
            this.quantityTextBox.Name = "quantityTextBox";
            this.quantityTextBox.Size = new System.Drawing.Size(109, 20);
            this.quantityTextBox.TabIndex = 53;
            // 
            // invoiceNoTextBox
            // 
            this.invoiceNoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "InvoiceNo", true));
            this.invoiceNoTextBox.Location = new System.Drawing.Point(551, 15);
            this.invoiceNoTextBox.Name = "invoiceNoTextBox";
            this.invoiceNoTextBox.Size = new System.Drawing.Size(198, 20);
            this.invoiceNoTextBox.TabIndex = 45;
            // 
            // amountTextBox
            // 
            this.amountTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "Amount", true));
            this.amountTextBox.Location = new System.Drawing.Point(329, 120);
            this.amountTextBox.Name = "amountTextBox";
            this.amountTextBox.Size = new System.Drawing.Size(109, 20);
            this.amountTextBox.TabIndex = 55;
            // 
            // departmentTextBox
            // 
            this.departmentTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "Department", true));
            this.departmentTextBox.Location = new System.Drawing.Point(83, 65);
            this.departmentTextBox.Name = "departmentTextBox";
            this.departmentTextBox.Size = new System.Drawing.Size(109, 20);
            this.departmentTextBox.TabIndex = 49;
            // 
            // descriptionTextBox
            // 
            this.descriptionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "Description", true));
            this.descriptionTextBox.Location = new System.Drawing.Point(83, 15);
            this.descriptionTextBox.Name = "descriptionTextBox";
            this.descriptionTextBox.Size = new System.Drawing.Size(109, 20);
            this.descriptionTextBox.TabIndex = 47;
            // 
            // dateDateTimePicker
            // 
            this.dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.invoiceKombataBindingSource, "Date", true));
            this.dateDateTimePicker.Location = new System.Drawing.Point(552, 123);
            this.dateDateTimePicker.Name = "dateDateTimePicker";
            this.dateDateTimePicker.Size = new System.Drawing.Size(197, 20);
            this.dateDateTimePicker.TabIndex = 57;
            // 
            // recievedByTextBox
            // 
            this.recievedByTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceKombataBindingSource, "recievedBy", true));
            this.recievedByTextBox.Location = new System.Drawing.Point(552, 71);
            this.recievedByTextBox.Name = "recievedByTextBox";
            this.recievedByTextBox.Size = new System.Drawing.Size(197, 20);
            this.recievedByTextBox.TabIndex = 59;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Peru;
            this.btnAdd.Location = new System.Drawing.Point(893, 565);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 31);
            this.btnAdd.TabIndex = 5;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Peru;
            this.btnExit.Location = new System.Drawing.Point(998, 622);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 31);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Peru;
            this.btnDelete.Location = new System.Drawing.Point(783, 565);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 31);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.BackColor = System.Drawing.Color.Peru;
            this.btnPrevious.Location = new System.Drawing.Point(998, 504);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(75, 31);
            this.btnPrevious.TabIndex = 2;
            this.btnPrevious.Text = "Previous";
            this.btnPrevious.UseVisualStyleBackColor = false;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.Color.Peru;
            this.btnNext.Location = new System.Drawing.Point(893, 504);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 31);
            this.btnNext.TabIndex = 1;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnSaveInvoice
            // 
            this.btnSaveInvoice.BackColor = System.Drawing.Color.Peru;
            this.btnSaveInvoice.Location = new System.Drawing.Point(783, 504);
            this.btnSaveInvoice.Name = "btnSaveInvoice";
            this.btnSaveInvoice.Size = new System.Drawing.Size(75, 31);
            this.btnSaveInvoice.TabIndex = 0;
            this.btnSaveInvoice.Text = "Save";
            this.btnSaveInvoice.UseVisualStyleBackColor = false;
            this.btnSaveInvoice.Click += new System.EventHandler(this.btnSaveInvoice_Click);
            // 
            // invoiceKombataTableAdapter
            // 
            this.invoiceKombataTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.InvoiceKombataTableAdapter = this.invoiceKombataTableAdapter;
            this.tableAdapterManager.LoginTableAdapter = null;
            this.tableAdapterManager.stockTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = LazanoFragrance.kombataDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // invoiceKombataBindingNavigator
            // 
            this.invoiceKombataBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.invoiceKombataBindingNavigator.BindingSource = this.invoiceKombataBindingSource;
            this.invoiceKombataBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.invoiceKombataBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.invoiceKombataBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.invoiceKombataBindingNavigatorSaveItem,
            this.toolStripSeparator8,
            this.LOGEDIN,
            this.toolStripSeparator9,
            this.toolStripLabel2,
            this.toolStripSeparator10,
            this.cmbSearch,
            this.toolStripSeparator11,
            this.txtSearch,
            this.toolStripSeparator12,
            this.btnSearch,
            this.toolStripSeparator7,
            this.lblTime});
            this.invoiceKombataBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.invoiceKombataBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.invoiceKombataBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.invoiceKombataBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.invoiceKombataBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.invoiceKombataBindingNavigator.Name = "invoiceKombataBindingNavigator";
            this.invoiceKombataBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.invoiceKombataBindingNavigator.Size = new System.Drawing.Size(1163, 25);
            this.invoiceKombataBindingNavigator.TabIndex = 10;
            this.invoiceKombataBindingNavigator.Text = "bindingNavigator1";
            this.invoiceKombataBindingNavigator.RefreshItems += new System.EventHandler(this.invoiceKombataBindingNavigator_RefreshItems);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // invoiceKombataBindingNavigatorSaveItem
            // 
            this.invoiceKombataBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.invoiceKombataBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("invoiceKombataBindingNavigatorSaveItem.Image")));
            this.invoiceKombataBindingNavigatorSaveItem.Name = "invoiceKombataBindingNavigatorSaveItem";
            this.invoiceKombataBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.invoiceKombataBindingNavigatorSaveItem.Text = "Save Data";
            this.invoiceKombataBindingNavigatorSaveItem.Click += new System.EventHandler(this.invoiceKombataBindingNavigatorSaveItem_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 25);
            // 
            // LOGEDIN
            // 
            this.LOGEDIN.Name = "LOGEDIN";
            this.LOGEDIN.Size = new System.Drawing.Size(54, 22);
            this.LOGEDIN.Text = "kombata";
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(42, 22);
            this.toolStripLabel2.Text = "Search";
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 25);
            // 
            // cmbSearch
            // 
            this.cmbSearch.Name = "cmbSearch";
            this.cmbSearch.Size = new System.Drawing.Size(200, 25);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(6, 25);
            // 
            // txtSearch
            // 
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(200, 25);
            this.txtSearch.Click += new System.EventHandler(this.txtSearch_Click);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(6, 25);
            // 
            // btnSearch
            // 
            this.btnSearch.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(23, 22);
            this.btnSearch.Text = "Search";
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 25);
            // 
            // lblTime
            // 
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(86, 22);
            this.lblTime.Text = "toolStripLabel3";
            // 
            // invoiceKombataDataGridView
            // 
            this.invoiceKombataDataGridView.AutoGenerateColumns = false;
            this.invoiceKombataDataGridView.BackgroundColor = System.Drawing.Color.Peru;
            this.invoiceKombataDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.invoiceKombataDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25});
            this.invoiceKombataDataGridView.DataSource = this.invoiceKombataBindingSource;
            this.invoiceKombataDataGridView.Location = new System.Drawing.Point(12, 504);
            this.invoiceKombataDataGridView.Name = "invoiceKombataDataGridView";
            this.invoiceKombataDataGridView.Size = new System.Drawing.Size(752, 172);
            this.invoiceKombataDataGridView.TabIndex = 10;
            this.invoiceKombataDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.invoiceKombataDataGridView_CellContentClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn1.HeaderText = "Name";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Address";
            this.dataGridViewTextBoxColumn2.HeaderText = "Address";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "City";
            this.dataGridViewTextBoxColumn3.HeaderText = "City";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Tel";
            this.dataGridViewTextBoxColumn4.HeaderText = "Tel";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "VatNo";
            this.dataGridViewTextBoxColumn5.HeaderText = "VatNo";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Bank";
            this.dataGridViewTextBoxColumn6.HeaderText = "Bank";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "AccNo";
            this.dataGridViewTextBoxColumn7.HeaderText = "AccNo";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "AccName";
            this.dataGridViewTextBoxColumn8.HeaderText = "AccName";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Name1";
            this.dataGridViewTextBoxColumn9.HeaderText = "Name1";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Address1";
            this.dataGridViewTextBoxColumn10.HeaderText = "Address1";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "City1";
            this.dataGridViewTextBoxColumn11.HeaderText = "City1";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Tel1";
            this.dataGridViewTextBoxColumn12.HeaderText = "Tel1";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "VatNo1";
            this.dataGridViewTextBoxColumn13.HeaderText = "VatNo1";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Bank1";
            this.dataGridViewTextBoxColumn14.HeaderText = "Bank1";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "AccNo1";
            this.dataGridViewTextBoxColumn15.HeaderText = "AccNo1";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "AccName1";
            this.dataGridViewTextBoxColumn16.HeaderText = "AccName1";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "TenderNo";
            this.dataGridViewTextBoxColumn17.HeaderText = "TenderNo";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "InvoiceNo";
            this.dataGridViewTextBoxColumn18.HeaderText = "InvoiceNo";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "Description";
            this.dataGridViewTextBoxColumn19.HeaderText = "Description";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "Department";
            this.dataGridViewTextBoxColumn20.HeaderText = "Department";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "unitPrice";
            this.dataGridViewTextBoxColumn21.HeaderText = "unitPrice";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "Quantity";
            this.dataGridViewTextBoxColumn22.HeaderText = "Quantity";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn23.HeaderText = "Amount";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "Date";
            this.dataGridViewTextBoxColumn24.HeaderText = "Date";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.Width = 120;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "recievedBy";
            this.dataGridViewTextBoxColumn25.HeaderText = "recievedBy";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Peru;
            this.button1.Location = new System.Drawing.Point(998, 565);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 31);
            this.button1.TabIndex = 11;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1163, 684);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.invoiceKombataDataGridView);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.invoiceKombataBindingNavigator);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.btnSaveInvoice);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Invoice";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceKombataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kombataDataSet)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceKombataBindingNavigator)).EndInit();
            this.invoiceKombataBindingNavigator.ResumeLayout(false);
            this.invoiceKombataBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceKombataDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RichTextBox rtfReceipt;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnSaveInvoice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btnNew;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btnSave;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton btnOpen;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton btnCopy;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton btnPaste;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton btnCut;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton btnPrint;
        private System.Windows.Forms.Label label2;
        private kombataDataSet kombataDataSet;
        private System.Windows.Forms.BindingSource invoiceKombataBindingSource;
        private kombataDataSetTableAdapters.InvoiceKombataTableAdapter invoiceKombataTableAdapter;
        private kombataDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator invoiceKombataBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton invoiceKombataBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox vatNoTextBox;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox bankTextBox;
        private System.Windows.Forms.TextBox telTextBox;
        private System.Windows.Forms.TextBox accNoTextBox;
        private System.Windows.Forms.TextBox accNameTextBox;
        private System.Windows.Forms.TextBox cityTextBox;
        private System.Windows.Forms.TextBox vatNo1TextBox;
        private System.Windows.Forms.TextBox city1TextBox;
        private System.Windows.Forms.TextBox bank1TextBox;
        private System.Windows.Forms.TextBox name1TextBox;
        private System.Windows.Forms.TextBox accNo1TextBox;
        private System.Windows.Forms.TextBox address1TextBox;
        private System.Windows.Forms.TextBox accName1TextBox;
        private System.Windows.Forms.TextBox tel1TextBox;
        private System.Windows.Forms.TextBox unitPriceTextBox;
        private System.Windows.Forms.TextBox tenderNoTextBox;
        private System.Windows.Forms.TextBox invoiceNoTextBox;
        private System.Windows.Forms.TextBox amountTextBox;
        private System.Windows.Forms.TextBox descriptionTextBox;
        private System.Windows.Forms.DateTimePicker dateDateTimePicker;
        private System.Windows.Forms.TextBox recievedByTextBox;
        private System.Windows.Forms.DataGridView invoiceKombataDataGridView;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripLabel LOGEDIN;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripComboBox cmbSearch;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripTextBox txtSearch;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripButton btnSearch;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripLabel lblTime;
        private System.Windows.Forms.ToolStripLabel lblDate;
        private System.Windows.Forms.TextBox departmentTextBox;
        private System.Windows.Forms.TextBox quantityTextBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.Button button1;
    }
}